import Hero from '../components/Hero';
import About from '../components/About';
import Menu from '../components/Menu';
import Specialties from '../components/Specialties';
import Reservation from '../components/Reservation';
import Blog from '../components/Blog';
import Contact from '../components/Contact';

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <Menu />
      <Specialties />
      <Reservation />
      <Blog />
      <Contact />
    </>
  );
}
