import { useParams, Link } from 'react-router-dom';
import { blogData } from '../data';
import { MessageCircle, ArrowLeft } from 'lucide-react';

export default function BlogPostPage() {
  const { id } = useParams();
  const post = blogData.find(p => p.id === Number(id));

  if (!post) {
    return (
      <div className="pt-32 pb-24 text-center min-h-screen flex flex-col justify-center items-center">
        <h1 className="text-3xl font-bold mb-4">Post not found</h1>
        <Link to="/blog" className="text-[#f89d13] font-bold hover:underline">Return to Blog</Link>
      </div>
    );
  }

  return (
    <div className="pt-24 bg-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Link to="/blog" className="inline-flex items-center text-[#f89d13] font-bold tracking-wider hover:text-gray-900 transition-colors uppercase mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Blog
        </Link>
        
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-6">{post.title}</h1>
          <div className="text-sm text-gray-500 flex justify-center items-center space-x-6">
            <span>{post.date}</span>
            <span>By {post.author}</span>
            <span className="flex items-center"><MessageCircle className="w-4 h-4 mr-1" /> {post.comments} Comments</span>
          </div>
        </div>

        <div className="rounded-xl overflow-hidden mb-12 h-64 md:h-96 shadow-xl relative">
          <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
        </div>

        <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed">
          <p className="text-xl text-gray-600 font-medium mb-8 leading-relaxed italic">
            {post.excerpt}
          </p>
          <p>
            {post.content}
          </p>
        </div>
      </div>
    </div>
  );
}
