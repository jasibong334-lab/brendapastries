import { blogData } from '../data';
import { MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function BlogPage() {
  return (
    <div className="pt-24 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <div className="text-[#f89d13] font-medium tracking-widest uppercase text-sm mb-2">Our Blog</div>
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Latest Updates & Stories</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogData.map((post) => (
            <div key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-2">
              <div className="h-64 overflow-hidden relative">
                <img src={post.image} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" />
              </div>
              <div className="p-6">
                <div className="text-sm text-gray-500 mb-3 flex items-center space-x-4">
                  <span>{post.date}</span>
                  <span>{post.author}</span>
                  <span className="flex items-center"><MessageCircle className="w-4 h-4 mr-1" /> {post.comments}</span>
                </div>
                <h3 className="text-xl font-serif font-bold text-gray-900 mb-4 hover:text-[#f89d13] transition-colors cursor-pointer">
                  {post.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {post.excerpt}
                </p>
                <Link to={`/blog/${post.id}`} className="text-sm font-bold tracking-wider text-[#f89d13] hover:text-gray-900 transition-colors uppercase">
                  Read More
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
