import { useState } from 'react';
import type { FormEvent } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const mailSubject = formData.subject || `Contact from ${formData.name}`;
    const body = `Name: ${formData.name}
Email: ${formData.email}

Message:
${formData.message}`;

    const link = document.createElement('a');
    link.href = `mailto:brendapastries20@gmail.com?subject=${encodeURIComponent(mailSubject)}&body=${encodeURIComponent(body)}`;
    link.click();
    
    // Clear the form after submission attempt
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-[#f89d13] font-medium tracking-widest uppercase text-sm mb-2">Contact Us</div>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Get In Touch</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-5 space-y-8">
            <div>
              <h3 className="text-xl font-bold font-serif text-gray-900 mb-2">Address</h3>
              <p className="text-gray-600">Akure, Nigeria</p>
            </div>
            <div>
              <h3 className="text-xl font-bold font-serif text-gray-900 mb-2">Phone</h3>
              <p className="text-[#f89d13] font-medium">+234-811-414-7463</p>
            </div>
            <div>
              <h3 className="text-xl font-bold font-serif text-gray-900 mb-2">Email</h3>
              <p className="text-[#f89d13] font-medium">brendapastries20@gmail.com</p>
            </div>
            <div>
              <h3 className="text-xl font-bold font-serif text-gray-900 mb-2">Website</h3>
              <p className="text-[#f89d13] font-medium">brendapastries.com</p>
            </div>
          </div>
          
          <div className="md:col-span-7">
            <form className="bg-gray-50 p-8 rounded-lg" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors bg-white" 
                    placeholder="Your Name" 
                  />
                </div>
                <div>
                  <input 
                    type="email" 
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors bg-white" 
                    placeholder="Your Email" 
                  />
                </div>
              </div>
              <div className="mb-6">
                <input 
                  type="text" 
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({...formData, subject: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors bg-white" 
                  placeholder="Subject" 
                />
              </div>
              <div className="mb-6">
                <textarea 
                  rows={6} 
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors bg-white resize-none" 
                  placeholder="Message"
                ></textarea>
              </div>
              <div>
                <button type="submit" className="bg-[#f89d13] hover:bg-[#e08b0f] text-white px-8 py-4 rounded-md text-sm font-bold uppercase tracking-wider transition-colors w-full md:w-auto min-w-[200px]">
                  Send Message
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
