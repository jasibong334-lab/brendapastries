import { Facebook, Twitter, Instagram } from 'lucide-react';
import { useState } from 'react';
import type { FormEvent } from 'react';

export default function Footer() {
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: FormEvent) => {
    e.preventDefault();
    const subject = 'Newsletter Subscription';
    const body = `Please add this email to the newsletter: ${email}`;
    const link = document.createElement('a');
    link.href = `mailto:brendapastries20@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    link.click();
    
    // Clear the input after submission attempt
    setEmail('');
  };

  return (
    <footer className="bg-gray-900 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          <div>
            <a href="#">
              <img src="/logo.png" alt="Brenda Pastries Logo" className="h-[80px] md:h-[88px] lg:h-[96px] w-auto object-contain mb-6 bg-white rounded-md p-2" />
            </a>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Delighting your taste buds with authentic Nigerian flavors and freshly baked pastries. Every bite is a sweet memory.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#f89d13] transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="https://web.facebook.com/asibong.brenda/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#f89d13] transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="https://www.instagram.com/callmhiebrenda" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#f89d13] transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://www.tiktok.com/@callmhiebrenda" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#f89d13] transition-colors">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-5 h-5"
                >
                  <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5v3a8 8 0 0 1-5-3z" />
                </svg>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 font-serif">Opening Hours</h3>
            <ul className="space-y-3 text-gray-400">
              <li className="flex justify-between">
                <span>Monday:</span>
                <span>09:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Tuesday:</span>
                <span>09:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Wednesday:</span>
                <span>09:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Thursday:</span>
                <span>09:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Friday:</span>
                <span>09:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Saturday:</span>
                <span>09:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between text-red-400">
                <span>Sunday:</span>
                <span>Closed</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 font-serif">Contact Information</h3>
            <ul className="space-y-4 text-gray-400">
              <li>Akure, Nigeria</li>
              <li>+234-811-414-7463</li>
              <li>brendapastries20@gmail.com</li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 font-serif">Newsletter</h3>
            <p className="text-gray-400 mb-4">
              Subscribe to our newsletter for the latest updates on freshly baked treats, special offers, and new menu additions.
            </p>
            <form className="flex flex-col space-y-3" onSubmit={handleSubscribe}>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email address" 
                className="bg-gray-800 border-none px-4 py-3 rounded text-white focus:ring-[#f89d13]"
              />
              <button type="submit" className="bg-[#f89d13] hover:bg-[#e08b0f] text-white px-4 py-3 rounded font-bold uppercase tracking-wider transition-colors">
                Subscribe
              </button>
            </form>
          </div>

        </div>

        <div className="border-t border-gray-800 pt-8 text-center text-gray-500">
          <p>
            Copyright &copy; {new Date().getFullYear()} All rights reserved | Brenda Pastries
          </p>
        </div>
      </div>
    </footer>
  );
}
