import { images } from '../data';

export default function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 md:hidden">
          <div className="mb-4 text-[#f89d13] font-medium tracking-widest uppercase text-sm">About</div>
          <h2 className="text-4xl font-serif font-bold text-gray-900">
            Our chef creates delicious memories for you
          </h2>
        </div>
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 w-full flex md:justify-center">
            <div className="w-full md:w-[120%] lg:w-[70%] relative">
              <img 
                src={images.about} 
                alt="About Brenda Pastries" 
                className="w-full h-auto object-cover md:object-contain rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-8 -right-8 bg-white p-4 hidden lg:block shadow-lg z-10">
                <img src={images.pastry} alt="Pastry" className="w-48 h-48 object-cover rounded" />
              </div>
            </div>
          </div>
          
          <div className="flex-1">
            <div className="hidden md:block">
              <div className="mb-4 text-[#f89d13] font-medium tracking-widest uppercase text-sm">About</div>
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-6">
                Our chef creates delicious memories for you
              </h2>
            </div>
            <p className="text-gray-600 mb-6 leading-relaxed">
              At Brenda Pastries, we take pride in serving the most authentic Nigerian dishes and the finest baked goods in Akure. From our signature Jollof rice to our mouth-watering meat pies and custom cakes, every dish is prepared with passion and the freshest ingredients.
            </p>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Whether you are looking for a quick bite, a family dinner, or catering for a special occasion, our menu is designed to satisfy all your cravings.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
