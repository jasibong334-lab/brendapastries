import { images } from '../data';

export default function Specialties() {
  const specialties = [
    {
      title: "Signature Jollof Rice",
      description: "Our world-famous Nigerian Jollof rice, cooked to perfection with a rich blend of tomatoes, peppers, and secret spices. Served with tender grilled chicken and fried plantain.",
      price: "2500",
      image: images.jollof
    },
    {
      title: "Delicious Small Chops",
      description: "A perfect mix of samosas, spring rolls, puff-puff, and grilled chicken wings. The ideal starter or party snack for any occasion.",
      price: "1500",
      image: images.pastry
    },
    {
      title: "Custom Celebration Cakes",
      description: "Beautifully designed and incredibly moist cakes for weddings, birthdays, and anniversaries. Made with premium ingredients and a lot of love.",
      price: "10000",
      image: images.cake
    }
  ];

  return (
    <section id="specialties" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-[#f89d13] font-medium tracking-widest uppercase text-sm mb-2">Our</div>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Specialties</h2>
        </div>

        <div className="space-y-16">
          {specialties.map((item, index) => (
            <div key={index} className={`flex flex-col md:flex-row items-center gap-12 ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
              <div className="flex-1 w-full relative">
                <div className="relative group overflow-hidden rounded-lg shadow-xl">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-[400px] object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-500"></div>
                </div>
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <div className="inline-block px-4 py-1 border border-[#f89d13] text-[#f89d13] font-bold text-lg mb-4 rounded">
                  ₦ {item.price}
                </div>
                <h3 className="text-3xl font-serif font-bold text-gray-900 mb-4">{item.title}</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  {item.description}
                </p>
                <a href="https://WA.me/2347013149259" target="_blank" rel="noopener noreferrer" className="inline-block text-[#f89d13] font-bold uppercase tracking-wider hover:text-gray-900 transition-colors">
                  Order Now <span className="ml-2">→</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
