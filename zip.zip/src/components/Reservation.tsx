import { useState } from 'react';
import type { FormEvent } from 'react';

export default function Reservation() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    person: '1 Person'
  });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const subject = `Reservation Request from ${formData.name}`;
    const body = `Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Date: ${formData.date}
Time: ${formData.time}
Party Size: ${formData.person}`;

    const mailtoLink = `mailto:brendapastries20@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoLink, '_blank', 'noopener,noreferrer');
    
    // Clear the form after submission attempt
    setFormData({
      name: '',
      email: '',
      phone: '',
      date: '',
      time: '',
      person: '1 Person'
    });
  };

  return (
    <section id="reservation" className="py-24 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-[#f89d13] font-medium tracking-widest uppercase text-sm mb-2">Pre-order</div>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Make Reservation</h2>
        </div>

        <form className="bg-white p-8 md:p-12 rounded-lg shadow-xl" onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Name</label>
              <input 
                type="text" 
                id="name" 
                required
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors" 
                placeholder="Your Name" 
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input 
                type="email" 
                id="email" 
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors" 
                placeholder="Your Email" 
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
              <input 
                type="tel" 
                id="phone" 
                required
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors" 
                placeholder="Phone Number" 
              />
            </div>
            <div>
              <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">Date</label>
              <input 
                type="date" 
                id="date" 
                required
                value={formData.date}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors" 
              />
            </div>
            <div>
              <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-2">Time</label>
              <input 
                type="time" 
                id="time" 
                required
                value={formData.time}
                onChange={(e) => setFormData({...formData, time: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors" 
              />
            </div>
            <div>
              <label htmlFor="person" className="block text-sm font-medium text-gray-700 mb-2">Person</label>
              <select 
                id="person" 
                value={formData.person}
                onChange={(e) => setFormData({...formData, person: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:ring-[#f89d13] focus:border-[#f89d13] outline-none transition-colors"
              >
                <option>1 Person</option>
                <option>2 People</option>
                <option>3 People</option>
                <option>4+ People</option>
              </select>
            </div>
          </div>
          <div className="text-center mt-8">
            <button type="submit" className="bg-[#f89d13] hover:bg-[#e08b0f] text-white px-8 py-4 rounded-md text-sm font-bold uppercase tracking-wider transition-colors w-full md:w-auto min-w-[200px]">
              Pre-order now
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}
