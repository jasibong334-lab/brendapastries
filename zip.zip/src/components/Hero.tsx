import { images } from '../data';

export default function Hero() {
  return (
    <div id="home" className="relative h-screen flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${images.hero})` }}
      >
        <div className="absolute inset-0 bg-black/50"></div>
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 font-serif">
          Tasty & Delicious Food
        </h1>
        <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
          Experience the best Nigerian delicacies and freshly baked pastries right here in Akure.
        </p>
        <a 
          href="#reservation" 
          className="inline-block bg-[#f89d13] hover:bg-[#e08b0f] text-white px-8 py-4 rounded-md text-sm font-bold uppercase tracking-wider transition-colors"
        >
          Pre-order now
        </a>
      </div>
    </div>
  );
}
