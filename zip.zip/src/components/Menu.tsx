import { menuData, images } from '../data';

export default function Menu() {
  return (
    <section id="menu" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-[#f89d13] font-medium tracking-widest uppercase text-sm mb-2">Discover</div>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-900">Our Menu</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Mains Column */}
          <div>
            <div className="flex items-center gap-4 mb-8">
              <img src={images.jollof} alt="Mains" className="w-16 h-16 rounded-full object-cover shadow-md" />
              <h3 className="text-2xl font-serif font-bold text-gray-900">Rice & Mains</h3>
            </div>
            <div className="space-y-6">
              {menuData.mains.map((item, index) => (
                <div key={index} className="flex justify-between items-baseline group">
                  <div className="flex-1">
                    <div className="flex items-baseline">
                      <h4 className="text-lg font-bold text-gray-900 pr-4">{item.name}</h4>
                      <div className="flex-1 border-b border-dashed border-gray-300"></div>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                  </div>
                  <div className="text-xl font-bold text-[#f89d13] pl-4 whitespace-nowrap">
                    ₦ {item.price.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pastries and Cakes Column */}
          <div className="space-y-12">
            <div>
              <div className="flex items-center gap-4 mb-8">
                <img src={images.pastry} alt="Pastries" className="w-16 h-16 rounded-full object-cover shadow-md" />
                <h3 className="text-2xl font-serif font-bold text-gray-900">Small Chops & Pastries</h3>
              </div>
              <div className="space-y-6">
                {menuData.pastries.map((item, index) => (
                  <div key={index} className="flex justify-between items-baseline group">
                    <div className="flex-1">
                      <div className="flex items-baseline">
                        <h4 className="text-lg font-bold text-gray-900 pr-4">{item.name}</h4>
                        <div className="flex-1 border-b border-dashed border-gray-300"></div>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                    </div>
                    <div className="text-xl font-bold text-[#f89d13] pl-4 whitespace-nowrap">
                      ₦ {item.price.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-4 mb-8">
                <img src={images.cake} alt="Cakes" className="w-16 h-16 rounded-full object-cover shadow-md" />
                <h3 className="text-2xl font-serif font-bold text-gray-900">Cakes</h3>
              </div>
              <div className="space-y-6">
                {menuData.cakes.map((item, index) => (
                  <div key={index} className="flex justify-between items-baseline group">
                    <div className="flex-1">
                      <div className="flex items-baseline">
                        <h4 className="text-lg font-bold text-gray-900 pr-4">{item.name}</h4>
                        <div className="flex-1 border-b border-dashed border-gray-300"></div>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                    </div>
                    <div className="text-xl font-bold text-[#f89d13] pl-4 whitespace-nowrap">
                      ₦ {item.price.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
