export const menuData = {
  mains: [
    { name: 'Jollof Rice', description: 'Classic Nigerian jollof rice with rich tomato base', price: 2500 },
    { name: 'Fried Rice', description: 'Stir-fried rice with mixed vegetables and liver', price: 2500 },
    { name: 'Pineapple Rice', description: 'Exotic rice served with pineapple chunks', price: 3000 },
    { name: 'Coconut Rice', description: 'Rice cooked in creamy coconut milk', price: 2800 },
    { name: 'Chicken and Chips', description: 'Crispy fried chicken served with french fries', price: 4500 },
  ],
  pastries: [
    { name: 'Fish and Meat Pie', description: 'Flaky pastry filled with minced meat or fish', price: 800 },
    { name: 'Sausage Rolls', description: 'Savory sausage wrapped in puff pastry', price: 700 },
    { name: 'Samosa', description: 'Crispy deep-fried triangular pastry with savory filling', price: 600 },
    { name: 'Eggrolls', description: 'Boiled egg wrapped in sweet dough and deep fried', price: 500 },
    { name: 'Fish and Meat Rolls', description: 'Spiced fish or meat filling in a soft roll', price: 800 },
    { name: 'Buns', description: 'Classic deep-fried sweet dough', price: 300 },
  ],
  cakes: [
    { name: 'All Sorts of Cakes', description: 'Custom cakes for all occasions (Starting price)', price: 10000 },
  ]
};

const getCurrentDate = (offsetDays = 0) => {
  const date = new Date();
  date.setDate(date.getDate() - offsetDays);
  const month = date.toLocaleDateString('en-US', { month: 'short' });
  const day = String(date.getDate()).padStart(2, '0');
  const year = date.getFullYear();
  return `${month}. ${day}, ${year}`;
};

export const blogData = [
  {
    id: 1,
    title: 'How to make the perfect Jollof Rice',
    date: getCurrentDate(0),
    author: 'Admin',
    image: "/enhanced_jollof.jpg",
    comments: 3,
    excerpt: "Discover the secrets to achieving that perfect smoky flavor and rich red color in your authentic Nigerian Jollof Rice.",
    content: "Jollof rice is more than just a meal; it's a cultural staple. To get the perfect smoky flavor, commonly known as 'party rice' flavor, you need the right balance of tomatoes, red bell peppers, scotch bonnets, and onions. The secret lies in the base—frying the tomato paste and blending the mix until it's perfectly reduced. Don't rush the process! Let the rice steam slowly in the rich sauce rather than boiling it rapidly. And the ultimate secret? Letting it catch slightly at the bottom for that authentic smoky essence."
  },
  {
    id: 2,
    title: 'The Secret to Flaky Meat Pies',
    date: getCurrentDate(1),
    author: 'Admin',
    image: "https://images.unsplash.com/photo-1600803907087-f56d462fd26b?auto=format&fit=crop&q=80&w=800",
    comments: 2,
    excerpt: "Learn how to bake meat pies with a perfectly golden, flaky crust and a rich, savory filling every time.",
    content: "The perfect Nigerian meat pie requires a delicate balance between a rich, savory filling and a buttery, flaky crust. The secret to the crust is using cold butter and ice water, handling the dough as little as possible to keep the gluten from overdeveloping. For the filling, a mix of minced meat, diced potatoes, and carrots, seasoned generously with thyme, curry powder, and a hint of bouillon, is essential. Always remember to egg-wash your pies before baking to achieve that beautiful golden-brown finish."
  },
  {
    id: 3,
    title: 'Top 5 Nigerian Snacks for Parties',
    date: getCurrentDate(2),
    author: 'Admin',
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=800",
    comments: 5,
    excerpt: "Planning an event? Here are the top 5 must-have Nigerian snacks that will keep your guests coming back for more.",
    content: "No Nigerian party is complete without 'small chops'. Our top 5 picks for any event are: 1. Samosas – crispy and filled with a savory mix of minced meat and vegetables. 2. Spring Rolls – light, crunchy, and packed with flavor. 3. Puff-Puff – the ultimate sweet, deep-fried dough balls that everyone loves. 4. Peppered Snail or Gizzard – for that spicy kick. 5. Sausage Rolls – a timeless classic. These finger foods are guaranteed to delight your guests and set the right mood for the main courses!"
  }
];

export const images = {
  hero: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=1920",
  jollof: "/enhanced_jollof.jpg",
  friedRice: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&q=80&w=800",
  chickenChips: "https://images.unsplash.com/photo-1599507593362-50fa53ed1b40?auto=format&fit=crop&q=80&w=800",
  pastry: "https://images.unsplash.com/photo-1600803907087-f56d462fd26b?auto=format&fit=crop&q=80&w=800",
  cake: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=800",
  about: "/about.jpg"
};
